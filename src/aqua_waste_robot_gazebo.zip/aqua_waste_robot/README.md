# Aqua Waste Detection Robot — Gazebo Simulation
## ROS2 Humble | Ubuntu 22.04

---

## 📁 Package Structure

```
~/ros2_ws/
└── src/
    └── aqua_robot_gazebo/
        ├── CMakeLists.txt
        ├── package.xml
        ├── worlds/
        │   └── lake_waste.world        ← MAIN WORLD FILE
        ├── urdf/
        │   └── aqua_robot.urdf         ← ROBOT MODEL
        ├── launch/
        │   └── lake_simulation.launch.py
        └── config/
            └── aqua_robot.rviz
```

---

## 🚀 STEP-BY-STEP SETUP

### Step 1 — Copy the package into your workspace

```bash
cp -r ~/aqua_waste_robot/src/aqua_robot_gazebo \
      ~/ros2_ws/src/
```

### Step 2 — Install dependencies

```bash
cd ~/ros2_ws

# Install ROS2 Gazebo integration (if not already installed)
sudo apt update
sudo apt install -y \
  ros-humble-gazebo-ros-pkgs \
  ros-humble-gazebo-ros \
  ros-humble-robot-state-publisher \
  ros-humble-joint-state-publisher \
  ros-humble-xacro \
  ros-humble-rviz2
```

### Step 3 — Build the package

```bash
cd ~/ros2_ws
colcon build --packages-select aqua_robot_gazebo
source install/setup.bash
```

### Step 4 — Launch the simulation

```bash
# Source ROS2 + Gazebo
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash

# If you have Intel integrated GPU (your setup), add these:
export LIBGL_ALWAYS_SOFTWARE=1
export MESA_GL_VERSION_OVERRIDE=3.3

# Launch everything
ros2 launch aqua_robot_gazebo lake_simulation.launch.py
```

This opens:
- **Gazebo** — the 3D lake world with the robot and waste objects
- **RViz2** — robot model + camera feed viewer

---

## 🌊 What's in the World

| Object | Count | Description |
|---|---|---|
| Water surface | 1 | Semi-transparent blue plane (z=0) |
| Lake bed | 1 | Brown floor at z=-3 m |
| Wave patches | 4 | Tilted highlight planes |
| Shore walls | 4 | Boundary (prevents robot leaving) |
| Algae patches | 6 | Green cylinders in 3 clusters |
| Plastic bottles | 9 | Bright coloured cylinders lying flat |
| Garbage piles | 4 | Brown rectangular debris |
| Foam chunks | 2 | White floating styrofoam |
| Plastic bags | 2 | Translucent grey flat objects |
| Robot | 1 | Blue catamaran with camera + sensor mast |

### Waste Distribution (natural-looking):
- **Dense zone**: top-right area (x≈10–20, y≈17–22) — bottles + garbage + foam
- **Medium zone**: centre (x≈3–8, y≈-12–5) — scattered bottles + garbage  
- **Light zone**: left side (x≈-20–-6) — lone bottle + bag + algae patches
- **Algae**: top-left cluster, bottom-right cluster, centre-left isolated patch

---

## 🤖 Robot Design

The **AquaBot** is a catamaran-style autonomous surface vehicle:

```
         [🟠 Camera + Orange Sensor Head]
              |  ← Mast (grey pole)
    ═══════════════════════════
    [  Blue Central Body Box  ]   ← Electronics housing
    ═══════════════════════════
   /                           \
  ●——— White Hull L ———●      ●——— White Hull R ———●
  ▼ Propeller                     ▼ Propeller
    [Yellow Bumper / Collector Bar at front]
```

| Component | Colour | Purpose |
|---|---|---|
| Central body | **Blue** | Electronics, battery housing |
| Twin hulls | **White** | Buoyancy, stability |
| Sensor mast | **Grey** | Elevates camera above water |
| Camera head | **Orange** | RGB camera (30 fps, 1280×720) |
| LiDAR disk | **Black** | Distance sensing |
| Bumper bar | **Yellow** | Front collision + waste collection guide |
| LED strip | **Green** | Status indicator (visible from above) |
| Propellers | **Dark grey** | Two rear thrusters |

---

## 🎮 Controlling the Robot

```bash
# In a new terminal (after launch):
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash

# Drive forward
ros2 topic pub /aqua_robot/cmd_vel geometry_msgs/msg/Twist \
  '{linear: {x: 0.5}, angular: {z: 0.0}}' --once

# Turn left
ros2 topic pub /aqua_robot/cmd_vel geometry_msgs/msg/Twist \
  '{linear: {x: 0.2}, angular: {z: 0.5}}' --once

# Stop
ros2 topic pub /aqua_robot/cmd_vel geometry_msgs/msg/Twist \
  '{linear: {x: 0.0}, angular: {z: 0.0}}' --once
```

---

## 📡 ROS2 Topics Published

| Topic | Type | Description |
|---|---|---|
| `/aqua_robot/camera/image_raw` | `sensor_msgs/Image` | Camera feed |
| `/aqua_robot/camera/camera_info` | `sensor_msgs/CameraInfo` | Camera calibration |
| `/aqua_robot/odom` | `nav_msgs/Odometry` | Robot position |
| `/robot_description` | `std_msgs/String` | URDF for RViz2 |
| `/joint_states` | `sensor_msgs/JointState` | Joint states |

---

## 🔧 Troubleshooting

### Gazebo opens but is black / grey
```bash
export LIBGL_ALWAYS_SOFTWARE=1
export MESA_GL_VERSION_OVERRIDE=3.3
# Then relaunch
```

### Robot spawns underground
Change `robot_z` argument:
```bash
ros2 launch aqua_robot_gazebo lake_simulation.launch.py robot_z:=0.5
```

### "Package not found" error
```bash
cd ~/ros2_ws
colcon build --packages-select aqua_robot_gazebo
source install/setup.bash
```

### Gazebo hangs on relaunch (your known issue!)
```bash
# Kill orphaned Gazebo processes first:
pkill -9 gzserver; pkill -9 gzclient; pkill -9 gazebo
sleep 2
ros2 launch aqua_robot_gazebo lake_simulation.launch.py
```

---

## 🔮 Next Steps (for autonomous waste detection)

1. **Add YOLO/object detection node** that subscribes to `/aqua_robot/camera/image_raw`
2. **Add a LiDAR sensor** to the `aqua_robot.urdf` (replace the visual-only disk)  
3. **Implement Nav2** for autonomous navigation between waste objects
4. **Add buoyancy plugin** (`gz-sim-buoyancy-system`) for realistic floating physics
5. **Add wave animation plugin** (`libgazebo_ros_water.so`) for dynamic waves
